# HustleHub+ – Secure Freelance Marketplace Platform (MERN)

> **POE Submission: Full-Stack Secure Marketplace with Role-Based Access Control, Financial Integrity & DevSecOps**

---

## 📌 Submission Checklist & Metadata

| Requirement | Artifact / Location | Status |
| :--- | :--- | :--- |
| **GitHub Repository** | `[YOUR_GITHUB_REPO_URL_HERE]` | ⚠️ *Add your remote repo URL before submission* |
| **Demonstration Video** | `[YOUR_LOOM_OR_YOUTUBE_VIDEO_LINK_HERE]` | ⚠️ *Record and paste video URL here* |
| **Architecture Diagram** | Included in Section 2 (ASCII) + *Attach your visual diagram PNG/PDF* | Complete / Ready |
| **Postman Collection** | `HustleHub_Plus_API.postman_collection.json` | Complete |
| **Newman Execution Runner** | `run-tests.js` | Complete |
| **Backend Unit Tests** | `server/test/api.test.js` (Run: `npm test`) | 12/12 Passing |
| **Frontend Unit Tests** | `client/src/test/` (Run: `npm test`) | Complete |
| **Local HTTPS SSL Certs** | `server/generate-certs.js` -> `server/certs/` | Complete |
| **Docker Containerisation** | `docker-compose.yml`, `server/Dockerfile`, `client/Dockerfile` | Complete |
| **CI/CD & DevSecOps Pipeline** | `.github/workflows/ci-cd.yml` | Complete |

---

## 1. System Overview & Intended Users

**HustleHub+** is a secure freelance marketplace platform built on the MERN stack (MongoDB, Express, React, Node.js). The platform connects service providers (freelancers) with clients while managing transactions, income tracking, and estimated tax obligations.

### Intended Users & Roles
1. **Clients**:
   - Register and authenticate securely.
   - Browse active marketplace gigs filtered by category.
   - Book services with simulated instant confirmation and custom project notes.
   - View their past booking history and expenditure.
2. **Freelancers**:
   - Manage their service listings (create, update details/prices, pause/activate, delete).
   - View incoming client bookings and fulfillment statuses.
   - Access the **Income & Tax Center** to monitor gross earnings, estimated provisional tax obligations, and net receipts.
   - View historical earnings ledgers with monthly aggregations.
3. **Administrators**:
   - Platform oversight: view gross platform volume, total transactions, user counts, and active listings.
   - System governance and auditing.

---

## 2. System Architecture & MERN Security Boundaries

```
┌──────────────────────────────────────────────────────────────────────────────────┐
│                             CLIENT TIER (React + Vite)                          │
│                                                                                  │
│   Single Page Application (SPA) · ProtectedRoute Guard · Axios JWT Interceptor   │
│   Auth Context · Role-Based Navigation · Local Storage (JWT Token Storage)       │
└────────────────────────────────────────┬─────────────────────────────────────────┘
                                         │  HTTPS / TLS 1.3 (Port 5000)
                                         │  Headers: Authorization: Bearer <jwt>
                                         ▼
┌──────────────────────────────────────────────────────────────────────────────────┐
│                         API SECURITY PERIMETER (Express.js)                      │
│                                                                                  │
│   [1] Helmet & CSP          -> Blocks XSS, clickjacking, MIME sniffing           │
│   [2] CORS Whitelist        -> Strictly permits origin http://localhost:5173     │
│   [3] Global Rate Limiter   -> 200 req / 15 min per IP                           │
│   [4] Auth Rate Limiter     -> 20 req / 15 min per IP (Brute-force protection)   │
│   [5] Booking Rate Limiter  -> 10 req / 15 min per IP (Spam prevention)          │
│   [6] mongoSanitize         -> Strips '$' and '.' (NoSQL Injection mitigation)   │
│   [7] xss-clean             -> Sanitises malicious HTML input tags               │
│   [8] express-validator     -> Type, syntax, length & regex input validation     │
└────────────────────────────────────────┬─────────────────────────────────────────┘
                                         │
                                         ▼
┌──────────────────────────────────────────────────────────────────────────────────┐
│                       APPLICATION CONTROLLERS & BUSINESS LOGIC                   │
│                                                                                  │
│   • Auth Controller (bcrypt cost 12, JWT sign/verify, role sanitisation)         │
│   • Gig Controller (Owner isolation via req.user._id, category filters)          │
│   • Booking Controller (Atomic booking creation with transaction generation)     │
│   • Transaction Controller (27% Provisional tax calculations, ledger grouping)   │
│   • Structured Event Logger (security-events.log audit trail)                    │
└────────────────────────────────────────┬─────────────────────────────────────────┘
                                         │  Mongoose ODM (BSON)
                                         ▼
┌──────────────────────────────────────────────────────────────────────────────────┐
│                         DATABASE TIER (MongoDB)                                  │
│                                                                                  │
│   Collections: Users | Gigs | Bookings | Transactions                            │
│   Indexes: compound & foreign keys on freelancer, client, status, createdAt     │
└──────────────────────────────────────────────────────────────────────────────────┘
```

> **📌 Notice for POE Submission**: A visual diagram matching the above components (Client Tier, API Security Gateway, Application Tier, and Database Tier) should be attached as a PNG/PDF in your repository or documentation folder.

---

## 3. Security Decisions & Implementation Deep Dive

### 3.1 Password Hashing (bcryptjs)
- Passwords are never stored in plain text.
- Passwords are salted and hashed using **bcryptjs with a salt factor of 12** via a Mongoose `pre('save')` hook.
- Password hashes and sensitive fields are explicitly projected out (`select('-password')`) on all user queries.

### 3.2 Token-Based Authentication (JWT)
- Authenticated sessions use cryptographically signed **JSON Web Tokens (JWT)** with a 7-day expiration.
- The `protect` middleware extracts the token from the `Authorization: Bearer <token>` header, verifies the signature using `process.env.JWT_SECRET`, and attaches the verified user to `req.user`.

### 3.3 Role-Based Access Control (RBAC)
- Routes enforce strict RBAC via `authorize(...roles)`.
- Self-registration is restricted to `client` and `freelancer` only. Any payload attempting to supply `admin` is explicitly rejected with `400 Bad Request` or `403 Forbidden` to prevent privilege escalation.
- Freelancers can only update, toggle, or delete gigs they own (`gig.freelancer === req.user._id`).
- Clients cannot create gigs or view freelancer financial ledger summaries.

### 3.4 Input Validation & Sanitisation
- All incoming payloads are validated using `express-validator`:
  - Emails are normalized and syntax-checked (`isEmail()`, `normalizeEmail()`).
  - Passwords require minimum length criteria.
  - Gig prices (R1 - R100,000) and delivery days (1 - 365) are numeric bounded.
  - IDs are checked with `isMongoId()`.
- `express-mongo-sanitize` strips `$` and `.` operators to prevent NoSQL query injection attacks.
- `xss-clean` strips script and HTML tags from user inputs.

### 3.5 Rate Limiting
- **Global Limiter**: 200 requests per 15-minute window per IP.
- **Authentication Limiter**: 20 login/register requests per 15-minute window to prevent password cracking and brute-force attacks.
- **Booking Limiter**: 10 booking requests per 15-minute window to prevent automated spam bookings.

### 3.6 Secure HTTP Headers & Content Security Policy (CSP)
- `helmet` is configured to set critical security headers:
  - `Content-Security-Policy` (CSP) restricts executable script origins and frame embedding.
  - `X-Content-Type-Options: nosniff` prevents MIME type sniffing.
  - `X-Frame-Options: DENY` blocks clickjacking attacks.

### 3.7 HTTPS with Local SSL Certificates
- The backend features native TLS/HTTPS support via Node's `https` module.
- Running `npm run generate:certs` creates self-signed 365-day SSL certificates (`server.key` and `server.cert`) in `server/certs/`.
- Toggling `USE_HTTPS=true` in `server/.env` boots the server over secure TLS (`https://localhost:5000`).

### 3.8 Atomic Booking & Transaction Generation
- Every client booking automatically generates a corresponding financial transaction record.
- Employs transactional sessions or compensating rollbacks: if transaction creation fails, the booking is aborted and removed, preventing orphaned booking records.

### 3.9 Financial Integrity & Tax Estimation
- Financial values are computed server-side from gig listings. The client cannot send custom amounts.
- **Estimated Tax**: Automatically calculated at a **27% provisional reference rate** (`amount * 0.27`).
- Visible disclaimer in UI and API: *Tax calculations are estimates for demonstration purposes only and do not constitute professional tax advice.*

### 3.10 Structured Security Event Logging
- Key events are logged to `server/logs/security-events.log` in structured JSON:
  - User registration, login successes, and authentication failures.
  - Privilege escalation attempts.
  - Gig creations, updates, and deletions.
  - Bookings completed and transaction generation.

---

## 4. Setup & Running Instructions

### Prerequisites
- **Node.js**: v18.0.0 or higher
- **MongoDB**: Local MongoDB instance (`mongodb://localhost:27017`) or MongoDB Atlas URI
- **Docker & Docker Compose** (optional, for containerised run)

---

### Option A: Local Development Run (Standard)

#### 1. Backend Setup
```bash
cd server
npm install

# 1. Generate SSL certificates for HTTPS (Part 1 requirement)
npm run generate:certs

# 2. Run backend unit tests
npm test

# 3. Start backend server
npm run dev
# Server will run on: http://localhost:5000 (or https://localhost:5000 if USE_HTTPS=true)
```

#### 2. Frontend Setup
```bash
cd client
npm install

# 1. Run frontend component tests
npm run test:run

# 2. Start Vite development server
npm run dev
# Frontend will run on: http://localhost:5173
```

---

### Option B: Docker Containerised Deployment

To run the entire platform (MongoDB + Express Backend + React SPA) inside isolated containers:

```bash
# From the project root directory:
docker-compose up --build
```

- **Frontend Application**: `http://localhost:3000`
- **Backend API**: `http://localhost:5000`
- **MongoDB Database**: `localhost:27017`

To shut down:
```bash
docker-compose down
```

---

## 5. Testing & Verification

### 1. Backend Unit & Security Tests
The backend includes automated tests using Node's native test runner and `supertest`:
```bash
cd server
npm test
```
**Tests Covered (12/12 Passing)**:
- Health check and security headers verification (Helmet nosniff, CSP).
- 400 Bad Request on empty or invalid registration inputs.
- 400 Bad Request on short passwords (< 6 chars).
- 400/403 rejection on unauthorized admin privilege escalation.
- 401 Unauthorized on unauthenticated protected requests.
- 401 Unauthorized on malformed or expired JWT tokens.
- RBAC validation on gigs and transaction routes.
- Sanitised 404 response without internal system details or stack traces.

### 2. Frontend Component Tests (Vitest)
```bash
cd client
npm run test:run
```
**Tests Covered**:
- `Login.test.jsx`: Form rendering, input binding, validation errors, submit behavior.
- `Register.test.jsx`: Form rendering, password matching, role selection, submission.
- `GigBrowse.test.jsx`: Marketplace rendering, category filters, loading and error states.
- `ProtectedRoute.test.jsx`: Unauthenticated redirection, role matching, role rejection.
- `Navbar.test.jsx`: Role-aware navigation links, active states, logout dispatch.

### 3. Automated API Endpoint Tests (Newman / Postman)
Ensure the server is running on port 5000, then execute:
```bash
node run-tests.js
```
The test runner will execute the `HustleHub_Plus_API.postman_collection.json` suite and generate an HTML report in `test-reports/report.html`.

---

## 6. API Route Reference

### Authentication (`/api/auth`)
| Method | Endpoint | Access | Description |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/auth/register` | Public | Register client or freelancer (admin blocked) |
| `POST` | `/api/auth/login` | Public | Login with email and password -> returns JWT |
| `GET` | `/api/auth/user` | Private | Retrieve current authenticated user profile |

### Marketplace Gigs (`/api/gigs`)
| Method | Endpoint | Access | Description |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/gigs` | Public | Browse all active gigs (optional `?category=` filter) |
| `GET` | `/api/gigs/my` | Freelancer | Retrieve all gigs owned by logged-in freelancer |
| `GET` | `/api/gigs/:id` | Public | View individual gig details |
| `POST` | `/api/gigs` | Freelancer | Create a new gig listing |
| `PUT` | `/api/gigs/:id` | Freelancer (Owner) | Update gig title, price, description, status |
| `DELETE` | `/api/gigs/:id` | Freelancer (Owner) | Delete/archive gig listing |

### Bookings (`/api/bookings`)
| Method | Endpoint | Access | Description |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/bookings` | Client | Book a gig (atomic booking + transaction created) |
| `GET` | `/api/bookings/my` | Private | Get user's bookings (clients see hires, freelancers see orders) |
| `GET` | `/api/bookings/:id` | Private | View specific booking details |

### Financial Transactions & Income (`/api/transactions`)
| Method | Endpoint | Access | Description |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/transactions/my` | Freelancer, Admin | Get financial ledger and 27% tax summary |
| `GET` | `/api/transactions/summary`| Freelancer | Get monthly earnings breakdown (`?year=YYYY`) |

---

## 7. Submission Artifacts Guide for the Student

As requested by the POE rubric, the following items must be supplied by the student:

1. **MERN Architecture Diagram**:
   - Save an image (e.g. `architecture-diagram.png`) in the project repository showing:
     - React Client -> Express API (with Helmet, CORS, Rate Limiters) -> Controllers/Services -> MongoDB Database.
2. **Demonstration Video**:
   - Record a brief video (Loom, YouTube unlisted, or MP4) showcasing:
     - The server booting (HTTPS/HTTP).
     - User registration as a client and freelancer.
     - Freelancer creating a gig listing.
     - Client browsing and booking the gig.
     - Freelancer viewing the confirmed booking and the Income & Tax dashboard with the 27% estimated tax calculations.
   - Insert the link at the top of this README.
3. **Screenshots**:
   - Take screenshots of your Postman / Newman test run results.
   - Take screenshots of the React application running in the browser.
