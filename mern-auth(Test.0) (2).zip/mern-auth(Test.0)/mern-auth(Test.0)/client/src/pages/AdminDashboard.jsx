import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import API from '../api/axios';

const AdminDashboard = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState({ gigs: 0, bookings: 0 });
  const [loadingStats, setLoadingStats] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [gigsRes, bookingsRes, txRes] = await Promise.all([
          API.get('/gigs'),
          API.get('/bookings/my'),
          API.get('/transactions/my'),
        ]);
        setStats({
          gigs: gigsRes.data.length,
          bookings: bookingsRes.data.length,
          transactions: txRes.data.summary?.transactionCount || 0,
          totalIncome: txRes.data.summary?.totalIncome || 0,
        });
      } catch {
        // silently fail
      } finally {
        setLoadingStats(false);
      }
    };
    fetchStats();
  }, []);

  return (
    <div className="role-dashboard">
      <div className="dashboard-header-card">
        <h2>Admin Portal</h2>
        <p>Welcome back, <strong>{user?.name}</strong>. You have full system access.</p>
        <span className="role-badge admin">Administrator</span>
      </div>

      <div className="dashboard-grid">
        <div className="dashboard-card">
          <h3>Marketplace Overview</h3>
          {loadingStats ? (
            <p>Loading…</p>
          ) : (
            <>
              <p className="stat-number">{stats.gigs} active gigs</p>
              <p>{stats.bookings} total bookings</p>
            </>
          )}
          <Link to="/gigs" className="btn-secondary">Browse All Gigs</Link>
        </div>

        <div className="dashboard-card">
          <h3>Platform Transactions</h3>
          {loadingStats ? (
            <p>Loading…</p>
          ) : (
            <>
              <p className="stat-number">{stats.transactions} transactions</p>
              <p>Total volume: <strong>R{(stats.totalIncome || 0).toLocaleString()}</strong></p>
            </>
          )}
          <Link to="/bookings" className="btn-secondary">View All Bookings</Link>
        </div>

        <div className="dashboard-card">
          <h3>Manage Gigs</h3>
          <p>View and moderate all platform listings.</p>
          <Link to="/gigs" className="btn-secondary">Go to Gigs</Link>
        </div>

        <div className="dashboard-card">
          <h3>Income Reports</h3>
          <p>Review platform-wide income and tax data.</p>
          <Link to="/income" className="btn-secondary">View Reports</Link>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
