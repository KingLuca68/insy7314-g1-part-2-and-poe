import { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import API from '../api/axios';

const TAX_RATE = 0.27;

const Income = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchIncome = async () => {
      try {
        const { data: res } = await API.get('/transactions/my');
        setData(res);
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to load income data.');
      } finally {
        setLoading(false);
      }
    };
    fetchIncome();
  }, []);

  const formatCurrency = (amount) =>
    `R${Number(amount).toLocaleString('en-ZA', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  const formatDate = (dateStr) =>
    new Date(dateStr).toLocaleDateString('en-ZA', {
      year: 'numeric', month: 'short', day: 'numeric',
    });

  return (
    <div className="page-wrapper">
      <Navbar />
      <main className="page-content">
        <div className="page-header">
          <h1>Income & Tax Overview</h1>
          <p>Track your earnings and estimated tax obligations.</p>
        </div>

        {error && <div className="error-banner" role="alert">{error}</div>}

        {loading ? (
          <div className="loading-center"><div className="spinner" /></div>
        ) : data ? (
          <>
            {/* Summary Cards */}
            <div className="income-summary-grid">
              <div className="income-card">
                <div className="action-card-header">
                  <div className="action-icon-bubble emerald">
                    <span>💵</span>
                  </div>
                  <span className="income-card-label">Gross Revenue</span>
                </div>
                <div className="income-card-value green">{formatCurrency(data.summary.totalIncome)}</div>
                <div className="income-card-sub">{data.summary.transactionCount} completed booking{data.summary.transactionCount !== 1 ? 's' : ''}</div>
              </div>

              <div className="income-card">
                <div className="action-card-header">
                  <div className="action-icon-bubble cyan">
                    <span>🏛️</span>
                  </div>
                  <span className="income-card-label">Tax Withholding</span>
                </div>
                <div className="income-card-value red">{formatCurrency(data.summary.totalEstimatedTax)}</div>
                <div className="income-card-sub">{(TAX_RATE * 100).toFixed(0)}% provisional reference rate</div>
              </div>

              <div className="income-card highlighted">
                <div className="action-card-header">
                  <div className="action-icon-bubble violet">
                    <span>✨</span>
                  </div>
                  <span className="income-card-label">Net Take-Home</span>
                </div>
                <div className="income-card-value">{formatCurrency(data.summary.totalNetIncome)}</div>
                <div className="income-card-sub">Disbursable profit after estimated tax</div>
              </div>
            </div>

            {/* Tax Disclaimer */}
            <div className="tax-note">
              <strong>⚠️ Tax Disclaimer:</strong> The estimated tax figure is calculated at a provisional rate of 27% for illustrative purposes only. 
              Consult a qualified tax practitioner for accurate South African income tax advice.
            </div>

            {/* Transactions Table */}
            <div className="transactions-section">
              <h2>Transaction History</h2>
              {data.transactions.length === 0 ? (
                <div className="empty-state"><p>No transactions yet. Start getting bookings!</p></div>
              ) : (
                <div className="transactions-table-wrapper">
                  <table className="transactions-table">
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>Gig</th>
                        <th>Client</th>
                        <th>Gross</th>
                        <th>Tax (27%)</th>
                        <th>Net</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.transactions.map((t) => (
                        <tr key={t._id}>
                          <td>{formatDate(t.createdAt)}</td>
                          <td className="td-gig">{t.gig?.title}</td>
                          <td>{t.client?.name}</td>
                          <td className="td-amount">{formatCurrency(t.amount)}</td>
                          <td className="td-tax">-{formatCurrency(t.estimatedTax)}</td>
                          <td className="td-net">{formatCurrency(t.netAmount)}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="totals-row">
                        <td colSpan={3}><strong>Totals</strong></td>
                        <td className="td-amount"><strong>{formatCurrency(data.summary.totalIncome)}</strong></td>
                        <td className="td-tax"><strong>-{formatCurrency(data.summary.totalEstimatedTax)}</strong></td>
                        <td className="td-net"><strong>{formatCurrency(data.summary.totalNetIncome)}</strong></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              )}
            </div>
          </>
        ) : null}
      </main>
    </div>
  );
};

export default Income;
